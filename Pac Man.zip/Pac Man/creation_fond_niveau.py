import pygame
from constante import *

pygame.init()

# Chargement image mur
mur = pygame.image.load("images/mur.png")

# ---------------------------
# LABYRINTHE 1 (tu mets toi-même les G)
# ---------------------------

Ligne0_1  = list('mmmmmmmmmmmmmmmmmmmmmmmmmmmmmm')
Ligne1_1  = list('mNNNNNNNNNNNNNNNGNNNNNNNNNNNNm')
Ligne2_1  = list('mNmmmmmNmmmmmNmmNmmmmmNmmmmmNm')
Ligne3_1  = list('mNmBBBmNmBBBmNmmNmBBBmNmBBBmNm')
Ligne4_1  = list('mNmBBBmNmBBBmNmmNmBBBmNmBBBmNm')
Ligne5_1  = list('mNmmmmmNmmmmmNmmNmmmmmNmmmmmNm')
Ligne6_1  = list('mNNNNNNNNNNNNNNNNNNNNNNNGNNNNm')
Ligne7_1  = list('mmmmmGmmmmmmNmmmmNmmmmmmNmmmmm')
Ligne8_1  = list('mBBBmNmNNNNNNNNNNNNNNNNmNmBBBm')
Ligne9_1  = list('mBBBmNmNmmmmmNmmNmmmmmNmNmBBBm')
Ligne10_1 = list('mBBBmNmNmmmmmNmmNmmmmmNmNmBBBm')
Ligne11_1 = list('mBBBmNmNNNNNNNNNNNNNNNNmNmBBBm')
Ligne12_1 = list('mmmmmNmmmmmmNmmmmNmmmmmmNmmmmm')
Ligne13_1 = list('mNNNNNNGNNNNNNNNNNNNNNNNNNNNNm')
Ligne14_1 = list('mNmmmmmNmmmmmNmmNmmmmmNmmmmmNm')
Ligne15_1 = list('mNmBBBmNmBBBmNmmNmBBBmNmBBBmNm')
Ligne16_1 = list('mNmBBBmNmBBBmNmmNmBBBmNmBBBmNm')
Ligne17_1 = list('mNmmmmmNmmmmmNmmNmmmmmNmmmmmNm')
Ligne18_1 = list('mNNNNNNNNNNNNNNNNNNNNNNGNNNNNm')
Ligne19_1 = list('mmmmmmmmmmmmmmmmmmmmmmmmmmmmmm')

# ---------------------------
# LABYRINTHE 2 (tu mets les “G” où tu veux)
# ---------------------------

Ligne0_2  = list('mmmmmmmmmmmmmmmmmmmmmmmmmmmmmm')
Ligne1_2  = list('mNNNNNNNNNNNGNNNNNNNNNNNNNNNNm')
Ligne2_2  = list('mNmmmmmNmmmmmmmmNmmmmmNmmmmmNm')
Ligne3_2  = list('mNmBBBmNmBBBBBBmNNNNNNNmBBBmNm')
Ligne4_2  = list('mNmmmmmNmBBBBBBmNmmmmmNmmmmmNm')
Ligne5_2  = list('mNNNNNNNmBBBBBBmNmBBBmNNNNGNNm')
Ligne6_2  = list('mNmmmmmNmmmmmmmmNmmmmmNmmmmmNm')
Ligne7_2  = list('mNmBBBmNNNNNNNNNNNNNNNNmBBBmNm')
Ligne8_2  = list('mNmBBBmNmmmmmNmmmmmmmmNmmmmmNm')
Ligne9_2  = list('mNmBBBmNmBBBmNmBBBBBBmNNNNNNNm')
Ligne10_2 = list('mNmBBBmNmBBBmNmBBBBBBmNmmmmmNm')
Ligne11_2 = list('mNmBBBmNmBBBmNmBBBBBBmNmBBBmNm')
Ligne12_2 = list('mNmmmmmNmmmmmNmBBBBBBmNmmmmmNm')
Ligne13_2 = list('mNNGNNNNNNNNNNmmmmmmmmNmmmmmNm')
Ligne14_2 = list('mNmmmmmmmmmmmNNNNNNNNNNNNNGNNm')
Ligne15_2 = list('mNmBBBBBBBBBmNmmmmmmmmNmmmmmNm')
Ligne16_2 = list('mNmBBBBBBBBBmNmBBBBBBmNmBBBmNm')
Ligne17_2 = list('mNmmmmmmmmmmmNmmmmmmmmNmmmmmNm')
Ligne18_2 = list('mNNNNNNNNNNNNNNNNNNNGNNNNNNNNm')
Ligne19_2 = list('mmmmmmmmmmmmmmmmmmmmmmmmmmmmmm')

L1 = [
    Ligne0_1, Ligne1_1, Ligne2_1, Ligne3_1, Ligne4_1,
    Ligne5_1, Ligne6_1, Ligne7_1, Ligne8_1, Ligne9_1,
    Ligne10_1, Ligne11_1, Ligne12_1, Ligne13_1, Ligne14_1,
    Ligne15_1, Ligne16_1, Ligne17_1, Ligne18_1, Ligne19_1
]

L2 = [
    Ligne0_2, Ligne1_2, Ligne2_2, Ligne3_2, Ligne4_2,
    Ligne5_2, Ligne6_2, Ligne7_2, Ligne8_2, Ligne9_2,
    Ligne10_2, Ligne11_2, Ligne12_2, Ligne13_2, Ligne14_2,
    Ligne15_2, Ligne16_2, Ligne17_2, Ligne18_2, Ligne19_2
]

def verification(tab):
    ok = True
    for i in range(len(tab)):
        if len(tab[i]) != 30:
            print("Erreur longueur ligne", i)
            ok = False
    return ok

def dessiner_niveau(L, nom):
    surface = pygame.Surface((longueur_fenetre, largeur_fenetre))
    surface.fill((0, 0, 0))

    for i in range(20):
        for j in range(30):
            x = j * taille_sprite
            y = i * taille_sprite
            if L[i][j] == "m":
                surface.blit(mur, (x, y))
            elif L[i][j] == "B":
                pygame.draw.rect(surface, (255, 255, 255),
                                 (x, y, taille_sprite, taille_sprite))

    pygame.image.save(surface, nom)

if __name__ == "__main__":
    if verification(L1):
        dessiner_niveau(L1, "images/niveau1.bmp")
    if verification(L2):
        dessiner_niveau(L2, "images/niveau2.bmp")
    print("Images générées")
