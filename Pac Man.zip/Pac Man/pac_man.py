import pygame
from pygame.locals import *
from constante import *
import creation_fond_niveau
import random

pygame.init()

# VARIABLES GLOBALES
fenetre = None
fond_niveau = None
font = None
pac = None
pac_original = None
pac_ligne = 1
pac_colonne = 1
position_perso = None
liste_fantomes = []
L_actuel = None

# --- POWER-UP ---
pouvoir = False
temps_pouvoir = 0

sprite_fantome_mort = pygame.image.load("images/fantomemort.png")
sprite_fantome_mort = pygame.transform.scale(sprite_fantome_mort, (taille_sprite, taille_sprite))


# ---------------- AFFICHAGE -----------------

def affichage_menu():
    global fenetre
    fenetre = pygame.display.set_mode((longueur_fenetre, largeur_fenetre))
    pygame.display.set_caption(titre_fenetre)

    # Charger l’image du menu
    img = pygame.image.load("images/menu.png").convert_alpha()
    img = pygame.transform.scale(img, (longueur_fenetre, largeur_fenetre))

    afficher = True

    while afficher:
        fenetre.blit(img, (0, 0))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                quit()

            if event.type == MOUSEBUTTONDOWN:
                afficher = False

def affichage_gagner():
    img = pygame.image.load("images/win.png").convert_alpha()
    img = pygame.transform.scale(img, (longueur_fenetre, largeur_fenetre))
    fenetre.blit(img, (0, 0))
    pygame.display.flip()
    pygame.time.wait(2000)
    pygame.quit()


def affichage_perdu():
    img = pygame.image.load("images/game_over.jpg").convert_alpha()
    img = pygame.transform.scale(img, (longueur_fenetre, largeur_fenetre))
    fenetre.blit(img, (0, 0))
    pygame.display.flip()
    pygame.time.wait(2000)
    pygame.quit()


# ------------ INTIALISATION -------------

def initialisation_fenetre(num):
    global fenetre, fond_niveau, font, L_actuel

    fenetre = pygame.display.set_mode((longueur_fenetre, largeur_fenetre))
    pygame.display.set_caption(titre_fenetre)

    if num == 1:
        fond_niveau = pygame.image.load("images/niveau1.bmp").convert()
        L_actuel = creation_fond_niveau.L1
    else:
        fond_niveau = pygame.image.load("images/niveau2.bmp").convert()
        L_actuel = creation_fond_niveau.L2

    font = pygame.font.SysFont("Comic Sans MS", 15)


def initialisation_pacman():
    global pac_original, pac, pac_ligne, pac_colonne, position_perso

    pac_original = pygame.image.load("images/pac_man.png").convert_alpha()
    pac_original = pygame.transform.scale(pac_original, (taille_sprite, taille_sprite))
    pac = pac_original

    pac_ligne = 1
    pac_colonne = 1
    position_perso = pygame.Rect(pac_colonne*taille_sprite,
                                 pac_ligne*taille_sprite,
                                 taille_sprite, taille_sprite)


def initialisation_fantomes(num):
    global liste_fantomes

    img1 = pygame.transform.scale(pygame.image.load("images/fantome1.png").convert_alpha(), (taille_sprite, taille_sprite))
    img2 = pygame.transform.scale(pygame.image.load("images/fantome2.png").convert_alpha(), (taille_sprite, taille_sprite))
    img3 = pygame.transform.scale(pygame.image.load("images/fantome3.png").convert_alpha(), (taille_sprite, taille_sprite))
    img4 = pygame.transform.scale(pygame.image.load("images/fantome4.png").convert_alpha(), (taille_sprite, taille_sprite))

    if num == 1:
        liste_fantomes = [
            {"ligne": 9, "colonne": 14, "vx": 1, "vy": 0, "image": img1, "image_originale": img1, "spawn": (9, 14)},
            {"ligne": 18, "colonne": 14, "vx": -1, "vy": 0, "image": img2, "image_originale": img2, "spawn": (18, 14)}
        ]
    else:
        liste_fantomes = [
            {"ligne": 8, "colonne": 10, "vx": 1, "vy": 0, "image": img3, "image_originale": img3, "spawn": (8, 10)},
            {"ligne": 13, "colonne": 8, "vx": 0, "vy": -1, "image": img4, "image_originale": img4, "spawn": (13, 8)}
        ]


# ---------------- DEPLACEMENTS -----------------

def deplacement_pacman(touches, ligne, col, vx, vy, L):
    global pac

    if touches[K_UP] and vy != 1:
        vx, vy = 0, -1
    elif touches[K_DOWN] and vy != -1:
        vx, vy = 0, 1
    elif touches[K_LEFT] and vx != 1:
        vx, vy = -1, 0
    elif touches[K_RIGHT] and vx != -1:
        vx, vy = 1, 0

    if vx == 1: pac = pac_original
    elif vx == -1: pac = pygame.transform.flip(pac_original, True, False)
    elif vy == -1: pac = pygame.transform.rotate(pac_original, 90)
    elif vy == 1: pac = pygame.transform.rotate(pac_original, -90)

    nl = ligne + vy
    nc = col + vx

    if L[nl][nc] != "m":
        ligne, col = nl, nc

    position = pygame.Rect(col * taille_sprite, ligne * taille_sprite, taille_sprite, taille_sprite)
    return ligne, col, position, vx, vy


def deplacement_fantomes(L):
    for i in liste_fantomes:
        nl = i["ligne"] + i["vy"]
        nc = i["colonne"] + i["vx"]

        if L[nl][nc] == "m":
            dire = []
            for vx, vy in [(1,0),(-1,0),(0,1),(0,-1)]:
                if L[i["ligne"]+vy][i["colonne"]+vx] != "m":
                    if vx == -i["vx"] and vy == -i["vy"]:
                        continue
                    dire.append((vx,vy))
            if dire:
                i["vx"], i["vy"] = random.choice(dire)
            nl = i["ligne"]+i["vy"]
            nc = i["colonne"]+i["vx"]

        i["ligne"] = nl
        i["colonne"] = nc


# ----------------- GOMMES ------------------

def placement_initial_gomme(L):
    laby = [list(ligne) for ligne in L]
    for i in range(20):
        for j in range(30):
            if L[i][j] == "N":
                laby[i][j] = "gomme"
            elif L[i][j] == "G":
                laby[i][j] = "super_gomme"
    laby[1][1] = "N"
    return laby


def affiche_gomme(laby, img_g, img_s):
    for i in range(20):
        for j in range(30):
            x = j*taille_sprite
            y = i*taille_sprite
            if laby[i][j] == "gomme":
                fenetre.blit(img_g, (x,y))
            elif laby[i][j] == "super_gomme":
                fenetre.blit(img_s, (x,y))


# ----------------- JEU ---------------------

def jouer_niveau(num):
    global pac_ligne, pac_colonne, position_perso
    global pouvoir, temps_pouvoir

    initialisation_fenetre(num)
    initialisation_pacman()
    initialisation_fantomes(num)

    img_gomme = pygame.transform.scale(pygame.image.load("images/pac_gomme.png").convert_alpha(), (taille_sprite, taille_sprite))
    img_super = pygame.transform.scale(pygame.image.load("images/pac_super_gomme.png").convert_alpha(), (taille_sprite, taille_sprite))

    laby = placement_initial_gomme(L_actuel)

    compteur = 0
    vx, vy = 1, 0
    clock = pygame.time.Clock()
    debut = pygame.time.get_ticks()

    continuer = True
    gagner = False
    perdu = False

    while continuer:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                quit()

        touches = pygame.key.get_pressed()
        duree = (pygame.time.get_ticks() - debut) // 1000

        pac_ligne, pac_colonne, position_perso, vx, vy = deplacement_pacman(
            touches, pac_ligne, pac_colonne, vx, vy, L_actuel
        )

        # MANGER GOMME
        if laby[pac_ligne][pac_colonne] == "gomme":
            compteur += 1
            laby[pac_ligne][pac_colonne] = "N"

        elif laby[pac_ligne][pac_colonne] == "super_gomme":
            compteur += 5
            laby[pac_ligne][pac_colonne] = "N"

            pouvoir = True
            temps_pouvoir = pygame.time.get_ticks()

            for i in liste_fantomes:
                i["image"] = sprite_fantome_mort

        # FIN DU POUVOIR
        if pouvoir and pygame.time.get_ticks() - temps_pouvoir >= 15000:
            pouvoir = False
            for i in liste_fantomes:
                i["image"] = i["image_originale"]

        # DEPLACEMENT FANTOMES
        deplacement_fantomes(L_actuel)

        # COLLISIONS
        for i in liste_fantomes:
            rect_i = pygame.Rect(i["colonne"]*taille_sprite,
                                 i["ligne"]*taille_sprite,
                                 taille_sprite, taille_sprite)

            if rect_i.colliderect(position_perso):

                if pouvoir:
                    i["ligne"], i["colonne"] = i["spawn"]
                else:
                    perdu = True
                    continuer = False

        # DEFAITE TEMPS
        if duree >= 90:
            perdu = True
            continuer = False

        # VICTOIRE
        if compteur >= 215:
            gagner = True
            continuer = False

        # AFFICHAGE
        fenetre.blit(fond_niveau, (0,0))
        affiche_gomme(laby, img_gomme, img_super)
        fenetre.blit(pac, position_perso)

        for i in liste_fantomes:
            r = pygame.Rect(i["colonne"]*taille_sprite,
                            i["ligne"]*taille_sprite,
                            taille_sprite, taille_sprite)
            fenetre.blit(i["image"], r)

        texte = font.render("Points : " + str(compteur),True,(255,255,255))
        fenetre.blit(texte, (0,0))
        texte = font.render("Time : " + str(duree), True, (255,255,255))
        fenetre.blit(texte, (120, 0))

        pygame.display.flip()
        clock.tick(5)

    return not perdu


# ----------------- JEU COMPLET ------------------

def jeu():
    if not jouer_niveau(1):
        affichage_perdu()
        return

    if not jouer_niveau(2):
        affichage_perdu()
    else:
        affichage_gagner()

affichage_menu()
jeu()
