"""Constantes du jeu PAC MAN""" 
#Paramètres de la fenêtre de jeu 
taille_sprite = 30
nbr_sprite_largeur = 20
largeur_fenetre =  600
nbr_sprite_longueur =  30
longueur_fenetre = 900

#Titre de la fenêtre 
titre_fenetre = "PAC-MAN"